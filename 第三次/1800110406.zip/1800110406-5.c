# include <stdio.h>
# include <math.h>
int main()
 {
   float a,b,b1;
   int c,c1;
   scanf("%f",&a);
   if(a>0&&a<1000)
   {
   b=sqrt(a);
   b1=-sqrt(a);
   c=(int)b;
   c1=(int)b1;
   printf("%d,%d\n",c,c1);
   }
   else
   printf("please enter again");
   return 0;
 }
