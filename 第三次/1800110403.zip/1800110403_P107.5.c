#include<stdio.h>
#include<math.h>
 int main()
 {
	 int a,b;
	 printf("please enter a number:");
	 scanf("%d",&a);
	 if(0<a&&a<1000)
	 {
		 b=sqrt(a);
		 printf("ta de ping fang gen shi:%d\n",b);
	 }
	 else
		 printf("please enter a number again:\n");
	 return 0;
 }