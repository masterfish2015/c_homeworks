#include<stdio.h>
#include<math.h>
int main()
{
int a,b;
scanf("%d",&a);
if(a<1000){
b=sqrt(a);
printf("%d",b);
}
else
printf("chongxinshuruyigeshu");
return 0;
}
