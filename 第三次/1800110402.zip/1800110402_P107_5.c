#include<stdio.h>
#include<math.h>
int main()
{
  int a,result;
  printf("Please input a number below 1000:");
  scanf("%d",&a);
  if(a>1000)
  {
    printf("Please input another number below 1000:");
	scanf("%d",&a);
  }
  result=sqrt(a);
  printf("%d\n",result);
  return 0;
}