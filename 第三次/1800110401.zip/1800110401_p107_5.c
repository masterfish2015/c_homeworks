#include <stdio.h>
#include <math.h>
int main ()
{
	int a,b;
	scanf("%d",&a);
	if(a<1000)
		b=sqrt(a);
	else
		scanf("%d",&a);
	    b=sqrt(a);
	printf("%d",b);
	return 0;
}
