#include<stdio.h>
#include<math.h>
int main()
{
	int b;
	double a;
	printf("shu ru yi ge zheng shu:");
	scanf("%lf",&a);
	if(a>1000)
	{
		printf("chong xin shu ru yi ge shu:");
		scanf("%lf",&a);
	}
	b=sqrt(a);
	printf("%d",b);
	return 0;
}
    






