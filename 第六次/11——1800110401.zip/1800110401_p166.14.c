#include<stdio.h>
int main()
{
    int a,d,i;
	char s1[10],s2[10];
    a=0;
	d=0;
	gets (s1);
	gets (s2);
	for(i=0;i<10;i++)
	{
		d=s1[i]-s2[i];
		a=a+d;
	}
	printf("%d\n",a);
	return 0;
}
