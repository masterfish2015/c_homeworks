#include<stdio.h>
int main()
{   int a[15];
	int i,j,t,s=0,b=14,c,mid;
	printf("input 15 number:\n");
	for(i=0;i<15;i++)
		scanf("%d",&a[i]);
	printf("\n");
	for(j=0;j<14;j++)
		for(i=0;i<14-j;i++)
		{
			if(a[i]>a[i+1])
			{
				t=a[i];
				a[i]=a[i+1];
				a[i+1]=t;
			}
		}
		for(i=0;i<15;i++)
		printf("%d\t",a[i]);
		printf("\n");
		printf("input a number:\n");
		scanf("%d",&c);
        while(s<=b)
		{
			mid=(s+b)/2;
		    if(c==a[mid])
			{
		    	printf("found the integer:%d",a[mid]);
		    	break;
			}
	    	else if(c>a[mid])
		    	s=mid+1;
	    	else b=mid-1;
		}
    	if(s>b)
	    	printf("Not found");
    	return 0;
}
