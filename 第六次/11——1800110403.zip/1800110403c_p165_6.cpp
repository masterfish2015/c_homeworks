#include<stdio.h>
#include<string.h>
int main()
{
	int str[10][10]={0},i,j;
	str[0][0]=1;str[1][0]=1;str[1][1]=1;
	for(i=2;i<10;i++)
	{
	for(j=0;j<10;j++)
	if(i==j||j==0)
	str[i][j]=1;
	else 
		str[i][j]=str[i-1][j-1]+str[i-1][j];
	}
	for(i=0;i<10;i++)
	{
	for(j=0;j<10;j++)
	if(str[i][j]!=0)
	printf("%11d",str[i][j]);
	printf("\n");
	}
	return 0;
}