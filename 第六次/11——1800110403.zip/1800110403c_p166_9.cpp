#include<stdio.h>
int main()
{
	int a[15],i,j,t,m,z=0;
	printf("input 15 numbers:\n");
	for(i=0;i<15;i++)
		scanf("%d",&a[i]);
	printf("\n");
	for(j=0;j<14;j++)
	 for(i=0;i<14-j;i++)
		if(a[i]>a[i+1])
		{t=a[i];a[i]=a[i+1];a[i+1]=t;}
    printf("the sorted numbers:\n");
	for(i=0;i<15;i++)
    	printf("%4d",a[i]);
	printf("\n");
	printf("enter a number:\n");
	scanf("%d",&m);
	for(i=0;i<15;i++)
		if(a[i]==m) 
        {
			printf("the number is exist in shu zu\n");
			z=1;
			break;
		}
    if(z!=1)	
		printf("no found\n");
	return 0;
}