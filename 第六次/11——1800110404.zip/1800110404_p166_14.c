#include<stdio.h>
main()
{
	char s1[100],s2[100];
	int c,i;
	printf("input the first string:\n");
	gets(s1);
	printf("input the second string:\n");
	gets(s2);
	for(i=0;;i++)
	if(s1[i]==s2[i])
			continue;
		else
		{
			c=s1[i]-s2[i];
	        printf("%d\n",c);
			break;
		}
	return 0;
}