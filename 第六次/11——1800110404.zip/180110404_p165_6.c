#include<stdio.h>
int main()
{
	int a[100][100]={0};
	int n,i,j;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=i;j++)
		{
			if(i==1||j==i)
			{
				a[i][j]=1;
				break;
			}
			a[i][j]=a[i-1][j-1]+a[i-1][j];
			printf("%4d",a[i][j]);
		}
		printf("\n");
	}
	return 0;
}