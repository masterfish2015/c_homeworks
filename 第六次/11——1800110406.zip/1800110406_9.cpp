# include<stdio.h>
int i,b,c,d[15];
int a[]={4,5,8,13,2,6,19,62,31,27,32,36,21,14,13} ;
int top=14,low=0,mid,e;
main()
{
    for(i=0;i<14;i++)
    for(b=0;b<14-i;b++)
    if(a[b]>a[b+1])
    {
    	c=a[b];
    	a[b]=a[b+1];
    	a[b+1]=c;
	}
	for(b=0;b<=14;b++)
	d[b]=a[b];
	
	mid=(top+low)/2;
	scanf("%d",&e);
	while(low<=top&&a[mid]!=e)
	{if(d[mid]>e)
	top=mid-1;
	else
	if(d[mid]==e)
	break;
	else
	low=mid+1;
	mid=(top+low)/2;
	}
	if(d[mid]==e)
	printf("This number is %dth number",mid+1);
    else
    printf(" search failed");
	return 0;
}
	

	
	
    


 
