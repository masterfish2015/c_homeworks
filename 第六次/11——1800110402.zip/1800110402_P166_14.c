#include<stdio.h>
int main()
{
	int i,result;
	char str1[200],str2[200];
	printf("input str1:");
	gets(str1);
	printf("input str2:");
	gets(str2);
	for(i=0;;i++)
		if(str1[i]==str2[i])
			continue;
		else
		{result=str1[i]-str2[i];
		printf("result=%d\n",result);
		break;}
	return 0;
}