#include<stdio.h>
int main()
{
	int a[15];
	int i,j,t,c;
	int e=0,f=14;
	int d=(e+f)/2;
	printf("input 15 numbers:\n");
	for(i=0;i<15;i++)
		scanf("%d",&a[i]);
	printf("\n");
	for(j=0;j<14;j++)
	  for(i=0;i<14-j;i++)
		  if(a[i]>a[i+1])
		  {t=a[i];a[i]=a[i+1];a[i+1]=t;}
	printf("the sorted numbers:\n");
	for(i=0;i<15;i++)
		printf("%3d",a[i]);
	printf("\n");
	printf("input a number:\n");
	scanf("%d",&c);
	while(e<=f)
	{d=(e+f)/2;
	  if(c==a[d])
	  {printf("found the number:%d",a[d]);break;}
	  else
		  if(c>a[d])
		   e=d+1;
		  else
		   f=d-1;
	}
	if(e>f)
	 printf("not found\n");
	return 0;

}