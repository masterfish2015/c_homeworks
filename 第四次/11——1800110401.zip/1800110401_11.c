#include <stdio.h>
int main ()
{
	int i,h,s;
	for(i=1,h=100,s=0;i<=10;i++)
	{
		s=s+h;
		h=1/2*h;
		i++;
	}
	printf ("%d,%d",s,h);
	return 0;
}