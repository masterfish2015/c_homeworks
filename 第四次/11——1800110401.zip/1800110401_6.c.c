#include <stdio.h>
int main ()
{
	double i,n,s;
	for (i=1.0,n=1.0,s=0;i<=20;i++)
	{
		n=n*i;
		s=s+n;
	}
	printf ("%lf\n",s);
	return 0;
}