#include<stdio.h>
#include<math.h>
main()
{
	double h=100,sum=100;
	int i=1;
	while(i<=9)
	{
		h=100*2*pow(1.0/2,i);
		sum=sum+h;
		i++;
	}
	printf("%lf\n",sum);
	return 0;
}

