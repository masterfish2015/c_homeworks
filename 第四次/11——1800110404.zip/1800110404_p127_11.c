#include<stdio.h>
int main()
{
	float a=100,n,sum=0;
	for(n=10;n>=0;n--)
	{
		sum=sum+2*a;
		a=a/2;
	}
	sum=sum-200;
	a=a*2;
	printf("gong jing guo=%f\n",sum);
	printf("dao du=%f",a);
	return 0;

}