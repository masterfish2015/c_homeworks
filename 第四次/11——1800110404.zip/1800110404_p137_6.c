#include<stdio.h>
main()
{
	double i=1,n,sum=0,a=1;
	printf("shu ru \"n\" de zhi:");
	scanf("%lf",&n);
	do{
		i=i*a;
		sum=sum+i;
		a++;
	}while(a<=n);
	printf("sum=%lf",sum);
	return 0;
}