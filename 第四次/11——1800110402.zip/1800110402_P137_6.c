#include<stdio.h>
int main()
{
	long double n,i=1,sum=0;
	for(n=1;n<=20;n++)
		{
         i=i*n;
		 sum=sum+i;
		}
	printf("sum=%lf\n",sum);
	return 0;
}