#include<stdio.h>
int main()
{
	float h=100.0,s=100.0;
    int i;
	for(i=2;i<=10;i++)
		{
	     h=h/2;
		 s=s+2*h;
		}
	h=h/2;
	printf("zong chang=%f\n",s);
	printf("gao du=%f\n",h);
	return 0;
}