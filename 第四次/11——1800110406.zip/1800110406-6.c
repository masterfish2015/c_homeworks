# include<stdio.h>
int main()
{
   int m;
   long long s=0,t;
   for(m=1,t=1;m<=20;m++)
   {
   t*=m;
   s+=t;
   }
   printf("%lld\n",s);
   return 0;
   }
