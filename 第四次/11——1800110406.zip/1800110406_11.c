# include <stdio.h>
int main ()
{
  int i;
  float a,t,s;
  a=100.0;
  for(i=1;i<=10;i++)
  {
  t=a/2;
  a=t;
  s=s+t;
  }
  s=(s-a)*2+100;
  printf("%f\n",s);
  printf("%f\n",a);
  return 0;
  }
