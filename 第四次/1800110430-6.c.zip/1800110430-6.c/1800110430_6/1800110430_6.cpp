#include<stdio.h>
main()
{
	long a=1,sum=0;
	int i;
	for(i=1;i<=20;i++)
	{a=a*i;
	sum=sum+a;}
	printf("%ld",sum);
	return 0;
}
